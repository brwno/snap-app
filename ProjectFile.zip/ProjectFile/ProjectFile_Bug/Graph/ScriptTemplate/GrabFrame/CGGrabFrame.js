let APJS=require("../../../amazingpro"),BaseNode=require("../Utils/BaseNode").BaseNode,GRAB_FRAME_OPENGLES_VS=`
#ifdef GL_ES
    precision highp float;
#endif
attribute vec3 attrPos;
attribute vec2 attrUV;
varying vec2 uv;

void main() {        
    gl_Position = vec4(attrPos.x, attrPos.y, attrPos.z, 1.0);       
    uv = attrUV;
}
`,GRAB_FRAME_OPENGLES_FS=`
#ifdef GL_ES
precision highp float;
#endif

uniform sampler2D _MainTex;
varying vec2 uv;
uniform float u_x;
uniform float u_w;
uniform float u_y;
uniform float u_h;

void main() {
    vec2 uvCrop;
    uvCrop = uv;
    uvCrop.x = u_x + uvCrop.x * u_w;
    uvCrop.y = u_y + uvCrop.y * u_h;
    vec4 color = texture2D(_MainTex, uvCrop);
    gl_FragColor = color;
}
`,GRAB_FRAME_METAL_VS=`#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct main0_out
{
    float2 uv;
    float4 gl_Position [[position]];
};

struct main0_in
{
    float3 attrPos [[attribute(0)]];
    float2 attrUV [[attribute(1)]];
};

vertex main0_out main0(main0_in in [[stage_in]])
{
    main0_out out = {};
    out.gl_Position = float4(in.attrPos.x, in.attrPos.y, in.attrPos.z, 1.0);
    out.uv = in.attrUV;
    out.gl_Position.z = (out.gl_Position.z + out.gl_Position.w) * 0.5;       // Adjust clip-space for Metal
    return out;
}`,GRAB_FRAME_METAL_FS=`
#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct main0_out
{
    float4 gl_FragColor [[color(0)]];
};

struct main0_in
{
    float2 uv;
};

fragment main0_out main0(main0_in in [[stage_in]], constant float& u_x [[buffer(0)]], constant float& u_w [[buffer(1)]], constant float& u_y [[buffer(2)]], constant float& u_h [[buffer(3)]], texture2d<float> _MainTex [[texture(0)]], sampler _MainTexSmplr [[sampler(0)]])
{
    main0_out out = {};
    float2 uvCrop = in.uv;
    uvCrop.x = u_x + (uvCrop.x * u_w);
    uvCrop.y = u_y + (uvCrop.y * u_h);
    float4 color = _MainTex.sample(_MainTexSmplr, uvCrop);
    out.gl_FragColor = color;
    return out;
}
`;class CGGrabFrame extends BaseNode{constructor(){super(),this.grabCommandBuffer=new APJS.CommandBuffer,this.inputTexture=null,this.cameraMap=new Map,this.cameraCount=0,this.blitMaterial=null,this.grabTexture=null,this.sys=null,this.enable=!1,this.cropRect=new APJS.Rect,this.hasRegisteredListener=!1}onInit(t){(this.sys=t)&&t.isSystem&&t.listenedCompTypeSet&&t.listenedCompTypeSet.add("Camera")}createRT(t,e){var i=new APJS.RenderTextureCreateDesc,t=(i.width=t,i.height=e,i.depth=1,i.filterMag=APJS.FilterMode.Linear,i.filterMin=APJS.FilterMode.Linear,i.filterMipmap=APJS.FilterMipmapMode.None,i.attachment=APJS.RenderTextureAttachment.NONE,APJS.TextureUtils.createRenderTexture(i));return t}addShaderToMap(t,e,i,r){var a=new APJS.Shader,i=(a.type=APJS.ShaderType.Vertex,a.source=i,new APJS.Shader),r=(i.type=APJS.ShaderType.Fragment,i.source=r,new APJS.Vector);r.pushBack(a),r.pushBack(i),t.insert(e,r)}createBlitMaterial(){var t=new APJS.Material,e=new APJS.Pass,i=new APJS.Map,i=(this.addShaderToMap(i,"gles2",GRAB_FRAME_OPENGLES_VS,GRAB_FRAME_OPENGLES_FS),this.addShaderToMap(i,"metal",GRAB_FRAME_METAL_VS,GRAB_FRAME_METAL_FS),e.shaders=i,new APJS.Map),i=(i.insert("attrPos",APJS.VertexAttribType.POSITION),i.insert("attrUV",APJS.VertexAttribType.TEXCOORD0),e.semantics=i,new APJS.StencilState);return e.depthTest=!1,e.stencilState=i,t.mainPass=e,t}beforeStart(t){this.blitMaterial=this.createBlitMaterial();var e=this.inputs[1]();e&&(this.grabTexture=this.createRT(e.getWidth(),e.getHeight()))}getOutput(t){return this.grabTexture}execute(t){!0!==this.enable&&(this.enable=!0,null===this.inputTexture||!1===this.inputTexture.equals(this.inputs[1]()))&&(this.cameraCount=0,this.inputTexture=this.inputs[1](),null!=this.inputTexture&&this.sys&&this.sys.APJScript)&&(null===this.grabTexture&&(this.grabTexture=this.createRT(this.inputTexture.getWidth(),this.inputTexture.getHeight())),this.registerListener())}onCallBack(t,e,i){!1!==this.enable&&(null!==this.inputs[2]()&&(this.cropRect=this.inputs[2]()),i===APJS.CameraEvent.AFTER_RENDER)&&this.cameraMap.has(e.guid.toString())&&(this.cameraCount=this.cameraCount+1,this.cameraCount===this.cameraMap.size)&&(i=e.renderTexture,null===this.blitMaterial&&(this.blitMaterial=this.createBlitMaterial()),this.grabTexture=this.createRT(this.inputTexture.getWidth(),this.inputTexture.getHeight()),this.blitMaterial.setFloat("u_x",this.cropRect.x),this.blitMaterial.setFloat("u_w",this.cropRect.width),this.blitMaterial.setFloat("u_y",this.cropRect.y),this.blitMaterial.setFloat("u_h",this.cropRect.height),this.grabCommandBuffer.clearAll(),this.grabCommandBuffer.blitWithMaterial(i,this.grabTexture,this.blitMaterial,0),this.sys.APJScene.commitCommandBuffer(this.grabCommandBuffer),this.enable=!1,this.cameraCount=0,this.nexts[0])&&this.nexts[0]()}resetOnRecord(t){this.grabCommandBuffer.clearAll(),this.grabCommandBuffer.setRenderTexture(this.grabTexture),this.grabCommandBuffer.clearRenderTexture(!0,!0,new APJS.Color(0,0,0,0),0),this.sys.APJScene.commitCommandBuffer(this.grabCommandBuffer),this.enable=!1,this.blitMaterial=null,this.cameraCount=0}registerListener(){var t,e;this.hasRegisteredListener&&this.removeListener(),this.cameraMap.clear();for(t of this.sys.isSystem?this.sys.listenedComponents:this.sys.APJScene.getAllSceneObjects().flatMap(t=>t.getComponents()))t.isInstanceOf("Camera")&&t.enabled&&(e=t.getSceneObject())&&e.enabled&&t.renderTexture.equals(this.inputTexture)&&(this.sys.eventListener.registerListener(this.sys.APJScript,APJS.CameraEvent.AFTER_RENDER,t,this.sys.APJScript),this.cameraMap.set(t.guid.toString(),t));this.hasRegisteredListener=!0}removeListener(){this.cameraMap.forEach(t=>{this.sys.eventListener.removeListener(this.sys.APJScript,APJS.CameraEvent.AFTER_RENDER,t,this.sys.APJScript)}),this.hasRegisteredListener=!1}onDestroy(){this.grabCommandBuffer=null,this.removeListener()}}exports.CGGrabFrame=CGGrabFrame;